<?php
    include 'core/init.php';
    include 'includes/overall/header.php';

    

    $smarty->display('list-of-users.tpl');
    include 'includes/overall/footer.php';
?>