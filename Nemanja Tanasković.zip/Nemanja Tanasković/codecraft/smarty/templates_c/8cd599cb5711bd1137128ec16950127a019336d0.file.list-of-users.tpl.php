<?php /* Smarty version Smarty-3.1.13, created on 2016-09-13 09:24:41
         compiled from "tpl\list-of-users.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2500757d7c3f1da1c16-48205714%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8cd599cb5711bd1137128ec16950127a019336d0' => 
    array (
      0 => 'tpl\\list-of-users.tpl',
      1 => 1473758394,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2500757d7c3f1da1c16-48205714',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57d7c3f1da5a33_28188572',
  'variables' => 
  array (
    'korisnici' => 0,
    'korisnik' => 0,
    'izmeni' => 0,
    'pomocni_korisnik' => 0,
    'p_k' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d7c3f1da5a33_28188572')) {function content_57d7c3f1da5a33_28188572($_smarty_tpl) {?>
<div id="list-of-users">
    <h3>List of users</h3>
</div>

<form class="w3-container w3-card-4" action="list-of-users.php" method="POST"> 
    <div class="table-responsive"> 
        <table class="table">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Privileges</th>
                <th>Active</th>
                <th>Spent</th>
                <th>Change</th>
                <th>Delete</th>
            </tr>
            <?php  $_smarty_tpl->tpl_vars['korisnik'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['korisnik']->_loop = false;
 $_smarty_tpl->tpl_vars['user_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['korisnici']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['korisnik']->key => $_smarty_tpl->tpl_vars['korisnik']->value){
$_smarty_tpl->tpl_vars['korisnik']->_loop = true;
 $_smarty_tpl->tpl_vars['user_id']->value = $_smarty_tpl->tpl_vars['korisnik']->key;
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['korisnik']->value->user_id;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['korisnik']->value->username;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['korisnik']->value->first_name;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['korisnik']->value->last_name;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['korisnik']->value->email;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['korisnik']->value->privileges;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['korisnik']->value->active;?>
</td>
                    <?php if ($_smarty_tpl->tpl_vars['korisnik']->value->potrosio!=0){?>
                        <td><?php echo $_smarty_tpl->tpl_vars['korisnik']->value->potrosio;?>
 RSD</td>
                    <?php }else{ ?>
                        <td>0 RSD</td>
                    <?php }?>
                    <td>
                        <button value="<?php echo $_smarty_tpl->tpl_vars['korisnik']->value->user_id;?>
" class="table_buttons table_buttons_blue"  name="izmeni_dugme">Izmeni</button>
                    </td>
                    <td>
                        <button value="<?php echo $_smarty_tpl->tpl_vars['korisnik']->value->user_id;?>
" class="table_buttons table_buttons_red" name="obrisi_dugme">Obriši</button>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>

    <?php if ($_smarty_tpl->tpl_vars['izmeni']->value==true){?>
        <div class="form-style-2">
            <div class="form-style-2-heading">Izmenite podatke</div>
                <?php  $_smarty_tpl->tpl_vars['p_k'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['p_k']->_loop = false;
 $_smarty_tpl->tpl_vars['user_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['pomocni_korisnik']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['p_k']->key => $_smarty_tpl->tpl_vars['p_k']->value){
$_smarty_tpl->tpl_vars['p_k']->_loop = true;
 $_smarty_tpl->tpl_vars['user_id']->value = $_smarty_tpl->tpl_vars['p_k']->key;
?>
                    <label for="username"><span>Korisničko ime</span>
                        <input type="text" class="input-field" name="username" value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->username;?>
" />
                    </label>

                    <label for="ime"><span>Ime</span>
                        <input type="text" class="input-field" name="ime" value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->first_name;?>
" />
                    </label>

                    <label for="prezime"><span>Prezime</span>
                        <input type="text" class="input-field" name="prezime" value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->last_name;?>
" />
                    </label>

                    <label for="email"><span>Email</span>
                        <input type="text" class="input-field" name="email" value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->email;?>
" />
                    </label>

                    <label for="aktivnost">
                        <?php if ($_smarty_tpl->tpl_vars['p_k']->value->active==0){?>
                            Neverifikovan <input type="radio" class="radio_button" name="aktivnost" value="0" checked/>
                            Verifikovan <input type="radio" class="radio_button" name="aktivnost" value="1" />
                        <?php }else{ ?>
                            Neverifikovan <input type="radio" class="radio_button" name="aktivnost" value="0"/>
                            Verifikovan <input type="radio" class="radio_button" name="aktivnost" value="1" checked/>
                        <?php }?>
                    </label>

                    <label for="privilegije"><span>Privilegije</span>
                        <?php if ($_smarty_tpl->tpl_vars['p_k']->value->privileges=='admin'){?>
                            <select name="privilegije" class="select-field1">
                                <option value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->privileges;?>
">Administrator</option>
                                <option value="user">Korisnik</option>
                                <option value="menager">Menadžer</option>
                            </select>
                        <?php }elseif($_smarty_tpl->tpl_vars['p_k']->value->privileges=='user'){?>
                            <select name="privilegije" class="select-field1">
                                <option value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->privileges;?>
">Korisnik</option>
                                <option value="menager">Menadžer</option>
                                <option value="admin">Administrator</option>
                            </select>
                        <?php }else{ ?>
                            <select name="privilegije" class="select-field1">
                                <option value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->privileges;?>
">Menadžer</option>
                                <option value="user">Korisnik</option>
                                <option value="admin">Administrator</option>
                            </select>
                        <?php }?>
                    </label>

                    <?php if ($_smarty_tpl->tpl_vars['p_k']->value->potrosio!=0){?>
                        <input type="hidden" name="potrosio" value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->potrosio;?>
">
                    <?php }else{ ?>
                        <input type="hidden" name="potrosio" value="0">
                    <?php }?>

                    <label>
                        <span>&nbsp;</span>
                        <button name="izmeni_final" class="f_dugme_manje" style="vertical-align:middle;" value="<?php echo $_smarty_tpl->tpl_vars['p_k']->value->user_id;?>
"><span>Izmeni</span></button>
                    </label>
                <?php } ?>
        </div>
    <?php }?>
</form><?php }} ?>