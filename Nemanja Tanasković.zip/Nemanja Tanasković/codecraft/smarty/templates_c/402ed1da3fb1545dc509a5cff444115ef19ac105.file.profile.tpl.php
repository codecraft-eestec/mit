<?php /* Smarty version Smarty-3.1.13, created on 2016-09-13 09:09:16
         compiled from "tpl\profile.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1364457d7ad4dd50b59-78687083%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '402ed1da3fb1545dc509a5cff444115ef19ac105' => 
    array (
      0 => 'tpl\\profile.tpl',
      1 => 1473757755,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1364457d7ad4dd50b59-78687083',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57d7ad4dd53960_09023579',
  'variables' => 
  array (
    'redirect' => 0,
    'empty_first_name' => 0,
    'empty_last_name' => 0,
    'empty_email' => 0,
    'empty_old_password' => 0,
    'empty_new_password' => 0,
    'wrong_old_password' => 0,
    'first_name' => 0,
    'last_name' => 0,
    'username' => 0,
    'email' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d7ad4dd53960_09023579')) {function content_57d7ad4dd53960_09023579($_smarty_tpl) {?><script>
    $(document).on('click', '#change_button', function(){
        var first_name = $('#first_name').text();
        var last_name = $('#last_name').text();
        var email = $('#email').text();

        $('#change_info').remove();
        var override = '<form action="profile.php" method="POST"><div id="info-for-change"><h3>Change your information</h3> <label for="first_name">First Name:</label>  <input type="text" name="first_name" value="' + first_name + '"> <label for="last_name">Last Name:</label> <input type="text" name="last_name" value="'+ last_name +'"> <label for="old_password">Old password:</label> <input type="password" name="old_password"> <label for="new_password">New password:</label> <input type="password" name="new_password"> <label for="email">Email:</label> <input type="text" name="email" value="'+ email +'"> <button name="final_change_button" class="w3-btn-block w3-teal">Submit</button>';
        document.getElementById("change-wrapper").innerHTML = override;
    });
</script>

<?php if ($_smarty_tpl->tpl_vars['redirect']->value==true){?>
    <div id="success">
        <h3>You have successfully changed your information. You will be redirected to home page in few seconds</h3>
    </div>
<?php }else{ ?>
    <?php if ($_smarty_tpl->tpl_vars['empty_first_name']->value==true){?>
        <div id="error">
            <h3>First Name is missing. Please try again</h3>
        </div>
    <?php }elseif($_smarty_tpl->tpl_vars['empty_last_name']->value==true){?>
        <div id="error">
            <h3>Last Name is missing. Please try again</h3>
        </div>
    <?php }elseif($_smarty_tpl->tpl_vars['empty_email']->value==true){?>
        <div id="error">
            <h3>Email is missing. Please try again</h3>
        </div>
    <?php }elseif($_smarty_tpl->tpl_vars['empty_old_password']->value==true){?>
        <div id="error">
            <h3>Old password is missing. Please try again</h3>
        </div>
    <?php }elseif($_smarty_tpl->tpl_vars['empty_new_password']->value==true){?>
        <div id="error">
            <h3>New password is missing. Please try again</h3>
        </div>
    <?php }elseif($_smarty_tpl->tpl_vars['wrong_old_password']->value==true){?>
        <div id="error">
            <h3>Wrong old password. Please try again</h3>
        </div>
    <?php }?>

    <div id="change-wrapper">
        <div id="change_info">
            <h3>Information</h3>
            <label for="first_name">First Name:</label> <div id="first_name"><?php echo $_smarty_tpl->tpl_vars['first_name']->value;?>
</div>
            <br>

            <label for="last_name">Last Name:</label> <div id="last_name"><?php echo $_smarty_tpl->tpl_vars['last_name']->value;?>
</div>
            <br>

            <label for="username">Username:</label> <div id="username"><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
</div>
            <br>

            <label for="email">Email:</label> <div id="email"><?php echo $_smarty_tpl->tpl_vars['email']->value;?>
</div>
            <br>

            <button name="change_button" id="change_button">Change</button>
        </div>
    </div>
<?php }?><?php }} ?>