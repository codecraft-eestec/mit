<?php /* Smarty version Smarty-3.1.13, created on 2016-09-13 11:12:48
         compiled from "tpl\registration.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3119357d726b37b93e1-89587071%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3f612523cc3b1142ac91960cf308cfb7aa89f9c6' => 
    array (
      0 => 'tpl\\registration.tpl',
      1 => 1473764938,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3119357d726b37b93e1-89587071',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57d726b389bb28_88480347',
  'variables' => 
  array (
    'companies' => 0,
    'company' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d726b389bb28_88480347')) {function content_57d726b389bb28_88480347($_smarty_tpl) {?><script>
    $(document).ready(function() {
        $('input[type=radio][name=type]').change(function() {
            var value = $('input[type=radio][name=type]:checked').val();

/*            var x = document.getElementById("my_company");
            var txt = [];
            var i;
            for (i = 0; i < x.length; i++) {
                txt[i] = x.options[i].text + "<br>";
            }
            var options_length = txt.length;
            document.getElementById("demo").innerHTML = txt;

            $.each(txt, function (i, txt) {
                $('#my_company').append($('<option>', { 
                    value: i,
                    text : i
                }));
            });*/

            if(value == 'personal')
            {
                var draw = '<div id="personal_input"><label for="first_name">First Name:</label><input type="text" name="first_name"> <label for="last_name">Last Name:</label> <input type="text" name="last_name"> <label for="username">Username:</label> <input type="text" name="username"> <label for="password">Password:</label> <input type="password" name="password"> <label for="email">Email:</label> <input type="text" name="email"> <label for="my_company">Select company that you work for</label><select name="my_company" id="my_company"></select></div>';
                document.getElementById("info-for-change").innerHTML = draw;
                
                $("#submit_button").attr('value', '1');
            }
            else if(value == 'company')
            {
                $('#personal_input').remove();
                var draw = '<div id="personal_input"><label for="company_name">Company Name:</label> <input type="text" name="company_name"> <label for="company_description">Company description</label> <textarea name="company_description" cols="30" rows="10"></textarea> <label for="pib">PIB</label> <input type="text" name="pib" maxlength="9"> <label for="first_name">First Name:</label> <input type="text" name="first_name"> <label for="last_name">Last Name:</label> <input type="text" name="last_name"> <label for="username">Username:</label> <input type="text" name="username"> <label for="password">Password:</label> <input type="password" name="password"> <label for="email">Email:</label> <input type="text" name="email"> </div>';
                document.getElementById("info-for-change").innerHTML = draw;
                $("#submit_button").attr('value', '2');
            }
        })});
</script>

<div id="demo"></div>

<div id="registration">
    <h3>Registration form</h3>
</div>

<div class="radio">
  <input id="personal" type="radio" name="type" value="personal" checked>
  <label for="personal">Personal</label>
  <input id="company" type="radio" name="type" value="company">
  <label for="company">Company</label>
</div>

<form action="registration.php" method="POST">
    <div id="info-for-change">
        <div id="personal_input">
            <label for="first_name">First Name:</label>
            <input type="text" name="first_name"> 

            <label for="last_name">Last Name:</label> 
            <input type="text" name="last_name">

            <label for="username">Username:</label> 
            <input type="text" name="username">

            <label for="password">Password:</label> 
            <input type="password" name="password"> 

            <label for="email">Email:</label> 
            <input type="text" name="email">

            <label for="my_company">Select company that you work for</label>
            <select name="my_company" id="my_company">
                <?php  $_smarty_tpl->tpl_vars['company'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['company']->_loop = false;
 $_smarty_tpl->tpl_vars['pib'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['companies']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['company']->key => $_smarty_tpl->tpl_vars['company']->value){
$_smarty_tpl->tpl_vars['company']->_loop = true;
 $_smarty_tpl->tpl_vars['pib']->value = $_smarty_tpl->tpl_vars['company']->key;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['company']->value->company_name;?>
"> <?php echo $_smarty_tpl->tpl_vars['company']->value->company_name;?>
 </option> 
                <?php } ?>
            </select>
        </div>
    </div>
    <button name="submit" class="w3-btn-block w3-teal" id="submit_button" value="1">Submit</button>
</form><?php }} ?>