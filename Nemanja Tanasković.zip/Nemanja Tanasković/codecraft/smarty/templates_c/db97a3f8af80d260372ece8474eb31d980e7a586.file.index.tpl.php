<?php /* Smarty version Smarty-3.1.13, created on 2016-09-12 16:25:06
         compiled from "tpl\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:100857d6b1359e9135-50866515%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'db97a3f8af80d260372ece8474eb31d980e7a586' => 
    array (
      0 => 'tpl\\index.tpl',
      1 => 1473697287,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '100857d6b1359e9135-50866515',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57d6b135b7f418_55282011',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d6b135b7f418_55282011')) {function content_57d6b135b7f418_55282011($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
    <title>CodeCraft takmičenje</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/mainstyle.css">
</head>
<body>

</body>
</html><?php }} ?>