<?php
    class User
    {
        public $user_id;
        public $username;
        public $first_name;
        public $last_name;
        public $email;
        public $privileges;
        public $active;
        public $spent;

        public function __construct($user_id, $username="", $first_name="", $last_name="", $email="", $privileges, $active, $spent)
        {
            $this->user_id              =   $user_id;
            $this->username             =   $username;
            $this->first_name           =   $first_name;
            $this->last_name            =   $last_name;
            $this->email                =   $email;
            $this->privileges           =   $privileges;
            $this->active               =   $active;
            $this->spent                =   $spent;
        }
    }
?>