<?php

    $db_password    = '';
    $host_name      = 'localhost';
    $db_name        = 'catering';
    $db_user        = 'root';

?>