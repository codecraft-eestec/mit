/*
    ime baze: catering
    usernme: root
    password:
*/

/* TABELE KREIRATI ISTIM REDOSLEDOM KAO STO SU OVDE NAVEDENE!!! */

CREATE TABLE `users` (
    `user_id`       int (11) NOT NULL auto_increment,
    `username`      varchar(32) NOT NULL,
    `password`      varchar(32) NOT NULL,
    `first_name`    varchar(32) NOT NULL,
    `last_name`     varchar(32) NOT NULL,
    `email`         varchar(1024) NOT NULL,
    `email_code`    varchar(32),
    `active`        int(1) DEFAULT 0,
    `privileges`    int(1) DEFAULT 0,
    `spent`         int (5) DEFAULT 0,
    `company`       int(11) NOT NULL,
    FOREIGN KEY (company) REFERENCES companies(pib),
    PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3;

INSERT INTO users (user_id, username, password, first_name, last_name, email, active, privileges, spent, company) VALUES 
(1,'nemanja','f5bb0c8de146c67b44babbf4e6584cc0','Nemanja','Tanaskovic','nemanjatanaskovic@elfak.rs', 1, 2, 0, 123213214),
(2,'marko','f5bb0c8de146c67b44babbf4e6584cc0','Marko','Stefanovic','mare@elfak.rs', 1, 1, 0, 123213214),
(3,'stefan','f5bb0c8de146c67b44babbf4e6584cc0','Stefan','Milovanovic','stefan@elfak.rs', 1, 0, 0, 123213214);

CREATE TABLE `companies` (
    `company_name`              varchar(100) NOT NULL,
    `company_description`       varchar(500) NOT NULL,
    `pib`                       int(11) NOT NULL,
    PRIMARY KEY  (`pib`)
) ENGINE=InnoDB;