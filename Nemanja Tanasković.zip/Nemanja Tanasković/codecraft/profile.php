<?php
    include 'core/init.php';
    include 'includes/overall/header.php';

    $first_name = $user_data['first_name'];
    $last_name = $user_data['last_name'];
    $username = $user_data['username'];
    $password = $user_data['password'];
    $email = $user_data['email'];
    $privileges = $user_data['privileges'];
    $spent = $user_data['spent'];

    $empty_first_name   = false;
    $empty_last_name    = false;
    $empty_email        = false;
    $empty_old_password = false;
    $empty_new_password = false;
    $wrong_old_password = false;
    $redirect           = false;

    if(isset($_POST['final_change_button']))
    {
        if(empty($_POST['first_name']))
            $empty_first_name = true;
        else if(empty($_POST['last_name']))
            $empty_last_name = true;
        else if(empty($_POST['old_password']))
            $empty_old_password = true;
        else if(empty($_POST['new_password']))
            $empty_new_password = true;
        else if(empty($_POST['email']))
            $empty_email = true;
        else if($password != md5($_POST['old_password']))
            $wrong_old_password = true;
        else
        {
            $user_id            = $user_data['user_id'];
            $first_name_final   = $_POST['first_name'];
            $last_name_final    = $_POST['last_name'];
            $password_final     = md5($_POST['new_password']);
            $email_final        = $_POST['email'];

            alter_user_as_user($user_id, $first_name_final, $last_name_final, $password_final, $email_final);
            $redirect = true;
            header( "refresh:3;url=index.php" );
        }
    }
    
    $smarty->assign('first_name', $first_name);
    $smarty->assign('last_name', $last_name);
    $smarty->assign('username', $username);
    $smarty->assign('password', $password);
    $smarty->assign('email', $email);
    $smarty->assign('privileges', $privileges);
    $smarty->assign('spent', $spent);

    $smarty->assign('empty_first_name', $empty_first_name);
    $smarty->assign('empty_last_name', $empty_last_name);
    $smarty->assign('empty_email', $empty_email);
    $smarty->assign('empty_old_password', $empty_old_password);
    $smarty->assign('empty_new_password', $empty_new_password);
    $smarty->assign('wrong_old_password', $wrong_old_password);
    $smarty->assign('redirect', $redirect);

    $smarty->display('profile.tpl');

    include 'includes/overall/footer.php';    
?>