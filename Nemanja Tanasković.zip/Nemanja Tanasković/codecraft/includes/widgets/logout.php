<ul class="nav navbar-nav navbar-right">
    <li class=""><a href="./profile.php">Profile</a></li>
    <li class=""><a href="./logout.php">Log out</a></li>
</ul>