<ul class="nav navbar-nav navbar-right">
    <li class=""><a href="./registration.php">Registration</a></li>
    <li class=""><a href="./login.php">Log in</a></li>
</ul>