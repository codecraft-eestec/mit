<!DOCTYPE html>
<html lang="en">
<?php
    include 'includes/head.php';
?>
<body>
    <div class="container-fixed">
        <?php
            include 'includes/header.php'
        ?>
        <div class="container-fluid">
        <div id="belaPozadina">