<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="./index.php">Home</a></li>
        <?php
          if (logged_in() === true)
          {
            $user_id = $_SESSION['user_id'];
            if(logged_in_as_admin($user_id) === true)
            {
        ?>
                <li class=""><a href="./list-of-users.php">List of users</a></li>
                <li class="dropdown">
                  <a class="dropdown-toggle" data-toggle="dropdown" href="#">Menu
                  <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li class=""><a href="./menu.php">Menu</a></li>
                    <li class=""><a href="./add-new-meal.php">Add new meal</a></li>
                    <li class=""><a href="./delete-meal.php">Delete meal</a></li>
                  </ul>
                </li>
                <li class=""><a href="./statistic.php">Statistic</a></li>
                <li class=""><a href="./contact.php">Contact</a></li>
              </ul>
        <?php
            }
            else
            {
        ?>
              <li class=""><a href="./menu.php">Menu</a></li>
              <li class=""><a href="./contact.php">Contact</a></li>
            </ul>
        <?php
            }
            include 'widgets/logout.php';
          }
          else
          {
        ?>
              <li class=""><a href="./contact.php">Contact</a></li>
            </ul>
        <?php
            include 'widgets/login.php';
          }
        ?>
    </div>
  </div>
</nav>