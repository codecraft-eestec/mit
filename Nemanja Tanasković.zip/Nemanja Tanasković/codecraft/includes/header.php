<header style="margin-top:20px;">
    <div class="container-fluid">
        <h1 class="logo"><a href="./index.php" style="color:#4ABDAC;">Catering logo</a></h1>
        <?php
          include 'includes/menu.php';
        ?>
    </div>
</header> 