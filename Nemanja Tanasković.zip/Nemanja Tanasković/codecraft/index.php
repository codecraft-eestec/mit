<?php
    include 'core/init.php';
    include 'includes/overall/header.php';


    $smarty->display('index.tpl');
    include 'includes/overall/footer.php';
?>