<?php

    $db_password    = '';
    $host_name      = 'localhost';
    $db_name        = 'codecraft';
    $db_user        = 'root';

?>