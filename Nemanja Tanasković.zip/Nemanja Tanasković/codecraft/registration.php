<?php
    include 'core/init.php';
    include 'includes/overall/header.php';

    $companies = return_companies();

    if(isset($_POST['submit']))
    {
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        if($_POST['submit'] == 1)
        {
            //personal
            $my_company = $_POST['my_company'];
        }
        else
        {
            //company
            $company_name = $_POST['company_name'];
            $company_description = $_POST['company_description'];
            $pib = $_POST['pib'];
            insert_company($company_name, $company_description, $pib);
        }
    }

    $smarty->assign('companies', $companies);
    $smarty->display('registration.tpl');
    include 'includes/overall/footer.php';
?>