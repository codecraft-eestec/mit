<?php
    class Company
    {
        public $company_name;
        public $company_description;
        public $pib;

        public function __construct($company_name="", $company_description="", $pib)
        {
            $this->company_name            =   $company_name;
            $this->company_description     =   $company_description;
            $this->pib                     =   $pib;
        }
    }
?>