<?php
function getImage($id){

		$servername = "localhost";
		$username = "root";
		$password = "";
		$db_name="catering";

		
		$conn = new mysqli($servername, $username, $password,$db_name);
		

	if (!$conn) 
    die("Connection failed: " . mysqli_connect_error());
    else
    {
    	$sql="select image_path from images where food_id='$id'";
    	if($res=$conn->query($sql))
        {
    	   $array=mysqli_fetch_assoc($res);
    	   $path=$array['image_path'];
        }

    	mysqli_close($conn);
    	return $path;
    }
}
?>