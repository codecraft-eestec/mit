<?php
	require '../core/db-init.php';

	$host_name      = 	$GLOBALS['host_name'];
	$db_user        = 	$GLOBALS['db_user'];
	$db_password    = 	$GLOBALS['db_password'];
	$db_name        = 	$GLOBALS['db_name'];

	$user_id 		= 	$_POST['user_id'];
	$id_food		=	$_POST['id_fo'];
	$comment		=	$_POST['comm'];

	$con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
    if ($con->connect_errno) 
        print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
    else
		$result = $con->query("INSERT INTO `comments`(`IDemployee`, `IDfood`, `comment`) VALUES ($user_id,$id_food,'$comment')");
?>