<?php
	require '../core/db-init.php';

	$shopping_card	=	$_POST['niz'];
	$order_date		=	$_POST['order_d'];
	$notes			=	$_POST['notes'];
	$user_id 		=	$_POST['user_id'];
	$company_id 	=	$_POST['company_id'];
	$today_day		=	date('d');

	if($order_date > $today_day)
		$date=date('Ym').$order_date;
	else
		$date=date('Y').(date('m')+1).$order_date;
	
	$con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
    if ($con->connect_errno) 
        print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
    else
    {
		for ($i=0; $i < count($shopping_card); $i++)
		{
			$result = $con->query("INSERT INTO `orders`(`IDfood`, `IDemployee`, `date`, `notes`, `company_id`, `type_of_meal`) VALUES ($shopping_card[$i], $user_id, $date, '$notes[$i]', $company_id, 1)");
		}
    }
?>