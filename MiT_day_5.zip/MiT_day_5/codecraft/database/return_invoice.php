<?php
	 include '../FoodOrders.php';
	 

     $selected_days   =$_GET['selected_days'];
     $selected_company=$_GET['selected_company'];
     
     $invoice_food=return_food_orders($selected_days, $selected_company);
        
        	
        echo "<table id='tableID'>
  		<tr>
	    <th>title</th>
		<th>description</th>
		<th>quantity</th>
		<th>unit of measure</th>
		<th>price</th>
	    <th>date</th>
		</tr>";
        foreach ($invoice_food as &$value) {
        echo "<tr>";
        echo "<td>$value->title</td>";
        echo "<td>$value->description</td>";
        $quantity_all=$value->quantity * $value->quantity_orders;
        echo "<td>$quantity_all</td>";
        echo "<td>$value->unit_of_measure</td>";
        $all_price=$value->price * $value->quantity_orders;
        echo "<td>$all_price $value->price_unit</td>";
        echo "<td>$value->date</td>";
        echo "</tr>";
        }
        echo "</table>";

        $all_price=0;
        $unit='';
        foreach ($invoice_food as &$value) {
        	$all_price+=($value->price * $value->quantity_orders);
        	$unit=$invoice_food[0]->price_unit;
        }
        echo "Total price: $all_price $unit";
        
?>