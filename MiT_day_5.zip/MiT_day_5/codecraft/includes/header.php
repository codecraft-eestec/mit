<header style="margin-top:20px;">
    <div class="container-fluid">
        <div id="logo">
            <a href="#"><img src="images/logo.png" class="img-responsive"></a>
        </div>
        <?php
          include 'includes/menu.php';
        ?>
    </div>
</header> 