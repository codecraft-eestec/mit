<div class="container-fluid">
    <footer style="text-align: center;">
    <div class="center">
        <p>&copy; MiT. All rights reserved</p></div>
    </footer>
</div>