<?php 
class Delivery_report
{
	public	$delivery_id;
	public	$company_id;
	public	$food_id;

	public function __construct($delivery_id, $company_id, $food_id)
	{
		$this->delivery_id = $delivery_id;
		$this->company_id=$company_id;
		$this->food_id=$food_id;
	}
}

?>