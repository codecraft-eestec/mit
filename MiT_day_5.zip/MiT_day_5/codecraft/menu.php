<?php
    include 'core/init.php';
    include 'includes/overall/header.php';

    $company_id     = $user_data['company'];
    $company        = get_company($company_id);
    $ketering_or_it = $company[0]->company_type;

    $meals = array();
    $images = array();
    if(isset($_GET['id']))
    {
        $pib = $_GET['id'];
        $admin = get_admin_id_for_company($pib);

        $admin_id = $admin[0]->user_id;
        $meals = return_meals($admin_id);

        foreach ($meals as $m) {
            $image = get_image($m->image_id);
            $images[] = $image[0]->image_path;

            $category = return_category($m->category_id);
            $categories[] = $category[0]->type;
        }

        $j = 0;
        foreach ($meals as $m) {
            $m->image_path = $images[$j];
            $m->category = $categories[$j];
            $j++;
        }
    }

    $smarty->assign('meals', $meals);
    $smarty->assign('ketering_or_it', $ketering_or_it);
    $smarty->display('menu.tpl');
    include 'includes/overall/footer.php';
?>