<?php 
    require 'core/db-init.php';
    
    $hidden_user_id = $_POST['hidden_user_id'];
    $automatic_delivery = $_POST['automatic_delivery'];

    $host_name      = $GLOBALS['host_name'];
    $db_user        = $GLOBALS['db_user'];
    $db_password    = $GLOBALS['db_password'];
    $db_name        = $GLOBALS['db_name'];

    $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
    if ($con->connect_errno) 
        print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
    else
        $result = $con->query("UPDATE users SET automatic_delivery = $automatic_delivery WHERE user_id = $hidden_user_id");
?>