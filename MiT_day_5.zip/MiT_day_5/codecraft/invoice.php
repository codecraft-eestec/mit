<?php
	include 'core/init.php';
	include 'includes/overall/header.php';
	//include 'return_invoice.php';
	//include 'database/return_invoice.php';
	 $host_name      = $GLOBALS['host_name'];
     $db_user        = $GLOBALS['db_user'];
     $db_password    = $GLOBALS['db_password'];
     $db_name        = $GLOBALS['db_name'];
     
    /* echo "$host_name";
     echo "$db_user";
     echo "$db_password";
     echo "$db_name";*/

	$all_companies=return_all_companies(0);

	$smarty->assign('all_companies',$all_companies);
	$smarty->assign('host_name ',$host_name );
	$smarty->assign('db_user',$db_user);
	$smarty->assign('db_password',$db_password);
	$smarty->assign('db_name',$db_name);

	$smarty->display('invoice.tpl');
    include 'includes/overall/footer.php';

?>