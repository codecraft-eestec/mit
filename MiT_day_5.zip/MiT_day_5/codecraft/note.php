<?php 

    undefined kad se ide na delete dugme u korpu...

 ?>