<?php
    require 'core/db-init.php';
    include 'User.php';

    function user_data($user_id)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $data = array();
        $user_id = (int)$user_id;

        $func_num_args = func_num_args();
        $func_get_args = func_get_args();

        if($func_num_args > 1)
        {
            unset($func_get_args[0]);
            
            $fields = '`' . implode('`, `', $func_get_args) . '`';

            $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
            if ($con->connect_errno) 
                print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
            else 
            {
                $res = $con->query("SELECT $fields FROM `users` WHERE `user_id` = $user_id");
                $row = $res->fetch_assoc();
                return $row;
            }
        }
    }

    function register_user($username, $password, $first_name, $last_name, $email, $active, $privileges, $spent, $company)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $password = md5($password);        
              $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else
            $res = $con->query("INSERT INTO users (username, password, first_name, last_name, email, active, privileges, spent, company) VALUES ('$username', '$password', '$first_name', '$last_name', '$email', $active, $privileges, $spent, $company)");
    }

    function get_admin_id_for_company($my_company)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
        {
            $res = $con->query("SELECT * FROM users WHERE company = $my_company AND privileges=1");
            if ($res) 
            {
                $niz = array();
                while ($row = $res->fetch_assoc()) 
                {
                    $niz[] = new User($row['user_id'], $row['username'], $row['first_name'], $row['last_name'], $row['email'], $row['privileges'], $row['active'], $row['spent'], $row['company'], $row['automatic_delivery'], $row['image']);
                }
                $res->close();
                return $niz;
            }
            else
                print ("Query failed");
        }
    }

    function logged_in()
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        return (isset($_SESSION['user_id'])) ? true : false;
    }

    function logged_in_as_admin($user_id)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
        {
            $res = $con->query("SELECT * FROM `users` WHERE `user_id` = $user_id AND `privileges` = 1");
            if(mysqli_num_rows($res) > 0)
                return true;
            else
                return false;
        }
    }

    function login($username, $password)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $password = md5($password);
        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
        {
            $res = $con->query("SELECT user_id FROM users WHERE username='$username' AND password='$password'");
            $u_id = mysqli_fetch_assoc($res);
            return $u_id['user_id'];
        }
    }

    function user_exists($username)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
        {
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        }
        else 
        {
            $res = $con->query("SELECT * FROM `users` WHERE `username` = '$username'");
            if(mysqli_num_rows($res) > 0)
                return true;
            else
                return false;
        }
    }

    function email_exists($email)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
        {
            $res = $con->query("SELECT * FROM `users` WHERE `email` = '$email'");
            if(mysqli_num_rows($res) > 0)
                return true;
            else
                return false;
        }        
    }

    function return_all_users()
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
        {
            $res = $con->query("SELECT * FROM users");
            if ($res) 
            {
                $niz = array();
                while ($row = $res->fetch_assoc()) 
                {
                    $niz[] = new User($row['user_id'], $row['username'], $row['first_name'], $row['last_name'], $row['email'], $row['privileges'], $row['active'], $row['spent'], $row['company'], $row['automatic_delivery'], $row['image']);
                }
                $res->close();
                return $niz;
            }
            else
                print ("Query failed");
        }
    }

    function return_users($pid)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
        {
            $res = $con->query("SELECT * FROM users WHERE company=$pid AND privileges=0");
            if ($res) 
            {
                $niz = array();
                while ($row = $res->fetch_assoc()) 
                {
                    $niz[] = new User($row['user_id'], $row['username'], $row['first_name'], $row['last_name'], $row['email'], $row['privileges'], $row['active'], $row['spent'], $row['company'], $row['automatic_delivery'], $row['image']);
                }
                $res->close();
                return $niz;
            }
            else
                print ("Query failed");
        }
    }

    function alter_user($username, $first_name, $last_name, $email, $status, $user_id)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno)
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
            $res = $con->query("UPDATE users SET username='$username', first_name = '$first_name', last_name='$last_name', email = '$email', active = $status WHERE user_id = $user_id");
    }

    function alter_user_img($img_id)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
            $res = $con->query("UPDATE users SET image=$img_id");
    }

    function accept_user($user_id)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
            $res = $con->query("UPDATE users SET active=1 WHERE user_id = $user_id");
    }

    function return_user($user_id)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
        {
            $res = $con->query("SELECT * FROM users WHERE user_id = $user_id");
            if ($res) 
            {
                $niz = array();
                while ($row = $res->fetch_assoc()) 
                {
                    $niz[] = new User($row['user_id'], $row['username'], $row['first_name'], $row['last_name'], $row['email'], $row['privileges'], $row['active'], $row['spent'], $row['company'], $row['automatic_delivery'], $row['image']);
                }
                $res->close();
                return $niz;
            }
            else
                print ("Query failed");
        }
    }

    function alter_user_as_user($user_id, $first_name, $last_name, $password, $email)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
            $res = $con->query("UPDATE users SET first_name='$first_name', last_name='$last_name', password='$password', email='$email' WHERE user_id = $user_id ");
    }

    function delete_user($user_id)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else 
            $res = $con->query("DELETE FROM users WHERE user_id = $user_id");
    }
?>