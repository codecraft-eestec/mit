<?php 
require 'core/db-init.php';
include 'Delivery_report.php';

function get_delivery_report($company_id)
{
    $host_name      = $GLOBALS['host_name'];
    $db_user        = $GLOBALS['db_user'];
    $db_password    = $GLOBALS['db_password'];
    $db_name        = $GLOBALS['db_name'];
	
    $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
    if ($con->connect_errno) 
        print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
    else 
    {
        $res = $con->query("SELECT * FROM delivery WHERE company_id = $company_id");
        if ($res)
        {
            $niz = array();
            while ($row = $res->fetch_assoc()) 
            {
                $niz[] = new Delivery_report($row['delivery_id'], $row['company_id'],$row['food_id']);
            }
            $res->close();
            return $niz;
        }
        else
            print ("Query failed");
    }

/*	$conn = new mysqli($host_name, $db_user, $db_password,$db_name);
	if (!$conn) 
    	die("Connection failed: " . mysqli_connect_error());

	$sql="select  pib, title, description,quantity, measure, category.name from food inner join quantity on quantity_ID=q_id inner join category on category_id=c_id inner join delivery on food_id=IDfood inner join companies on companies.pib=delivery.IDcompany where delivery.IDfood=food.food_id;";
			
	$res=$conn->query($sql);	
	$index=0;
	$array= [];
	while($row=mysqli_fetch_assoc($res))
	{
		$obj= new delivery($row['pib'],$row['title'],$row['description'],$row['quantity'],$row['measure'],$row['name']);
		$array[$index]=$obj;
		$index++;
	}

	mysqli_close($conn);
	return $array;*/
}
?>

