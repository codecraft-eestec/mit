<?php 
    require 'core/db-init.php';
    include 'Order.php';

    function insert_order($IDfood, $IDemployee, $date, $company_id, $type_of_meal, $quantity, $note)
    {
        $host_name      = $GLOBALS['host_name'];
        $db_user        = $GLOBALS['db_user'];
        $db_password    = $GLOBALS['db_password'];
        $db_name        = $GLOBALS['db_name'];

        $con = new mysqli("$host_name", "$db_user", "$db_password", "$db_name");
        if ($con->connect_errno) 
            print ("Connection error (" . $con->connect_errno . "): $con->connect_error");
        else
            $res = $con->query("INSERT INTO orders (IDfood, IDemployee, `date`, company_id, type_of_meal, quantity, notes) VALUES ($IDfood, $IDemployee, $date, $company_id, '$type_of_meal', $quantity, '$note')");
    }

?>