<?php
    class Company
    {
        public $company_name;
        public $company_description;
        public $pib;
        public $company_type;
        public $type_of_plan;
        public $breakfast_time;
        public $breakfast_time_type;
        public $lunch_time;
        public $lunch_time_type;

        public function __construct($company_name="", $company_description="", $pib, $company_type, $type_of_plan, $breakfast_time, $breakfast_time_type="", $lunch_time, $lunch_time_type="")
        {
            $this->company_name            =   $company_name;
            $this->company_description     =   $company_description;
            $this->pib                     =   $pib;
            $this->company_type            =   $company_type;
            $this->type_of_plan            =   $type_of_plan;
            $this->breakfast_time          =   $breakfast_time;
            $this->breakfast_time_type     =   $breakfast_time_type;
            $this->lunch_time              =   $lunch_time;
            $this->lunch_time_type         =   $lunch_time_type;
        }
    }
?>