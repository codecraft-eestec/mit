        [[foreach from = $food_array item = item]]
            <div id="comments_id[[$item->food_ID]]">
                [[foreach from=$item->comments item=item_com]]
                    [[$item_com]]
                [[/foreach]]

                [[foreach from=$item->usernames item=usernames]]
                    [[$usernames]]
                [[/foreach]]
            </div>
            [[if $item->comment_array eq 'TRUE']]
                <textarea id="note[[$item->food_ID]]"></textarea>
                <button onclick="add_comment([[$item->food_ID]])">Prokomentarisi</button>
            [[/if]]
            <button onclick="get([[$item->food_ID]], '[[$item->title]]')">[[$item->title]]</button><br>
            <div class="col-md-6">
                <div id="meal-block">
                    <div class="row">
                        <div class="col-md-6">
                            <img onclick="get([[$item->food_ID]], '[[$item->title]]')" src="[[$image_paths[$counter++] ]]" width="200" height="200" />
                        </div>
                        <div class="col-md-6">
                            <h2>[[$item->title]]</h2>
                        </div>
                    </div>
                </div>
            </div>
        [[/foreach]]