<?php /* Smarty version Smarty-3.1.13, created on 2016-09-17 11:10:46
         compiled from "tpl\menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:317157dd1e51180698-05226391%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fa897218cb7e974a586b0faf825925ad352648c3' => 
    array (
      0 => 'tpl\\menu.tpl',
      1 => 1474110645,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '317157dd1e51180698-05226391',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57dd1e512003d1_85723086',
  'variables' => 
  array (
    'meals' => 0,
    'm' => 0,
    'ketering_or_it' => 0,
    'x' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57dd1e512003d1_85723086')) {function content_57dd1e512003d1_85723086($_smarty_tpl) {?><div class="row">
    <div class="col-md-8">
        <?php  $_smarty_tpl->tpl_vars['m'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['m']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['meals']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['m']->key => $_smarty_tpl->tpl_vars['m']->value){
$_smarty_tpl->tpl_vars['m']->_loop = true;
?>
            <div class="row">
                <div class="col-md-6">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['m']->value->image_path;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['m']->value->title;?>
" class="img-responsive">
                </div>
                <div class="col-md-6">
                    <?php if ($_smarty_tpl->tpl_vars['ketering_or_it']->value==0){?>
                            <div class="col-md-6">
                                <h2><a href="menu.php?id=<?php echo $_smarty_tpl->tpl_vars['m']->value->food_ID;?>
"><?php echo $_smarty_tpl->tpl_vars['m']->value->title;?>
</a></h2>
                                <hr>
                                <p>Price: <?php echo $_smarty_tpl->tpl_vars['m']->value->price;?>
 <?php echo $_smarty_tpl->tpl_vars['m']->value->price_unit;?>
</p>
                                <p>Category: <a href="index.php?category=<?php echo $_smarty_tpl->tpl_vars['m']->value->category_id;?>
"><?php echo $_smarty_tpl->tpl_vars['m']->value->category;?>
</a></p>
                                <button onclick="get(<?php echo $_smarty_tpl->tpl_vars['m']->value->food_ID;?>
, '<?php echo $_smarty_tpl->tpl_vars['m']->value->title;?>
')" type="button" class="btn btn-default btn-sm">
                                    <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
                                </button>
                            </div>
                        <?php }else{ ?>
                            <div class="col-md-6">
                                <h2><a href="menu.php?id=<?php echo $_smarty_tpl->tpl_vars['m']->value->food_ID;?>
"><?php echo $_smarty_tpl->tpl_vars['m']->value->title;?>
</a></h2>
                                <hr>
                                <p>Price: <?php echo $_smarty_tpl->tpl_vars['meals']->value[$_smarty_tpl->tpl_vars['x']->value]->price;?>
 <?php echo $_smarty_tpl->tpl_vars['m']->value->price_unit;?>
</p>
                                <p>Category: <a href="index.php?category=<?php echo $_smarty_tpl->tpl_vars['m']->value->category_id;?>
"><?php echo $_smarty_tpl->tpl_vars['m']->value->category;?>
</a></p>
                            </div>
                        <?php }?>
                </div>
            </div>
            <hr>
        <?php } ?>
    </div>
        <div class="col-md-4">
            fiksni div
        </div>
</div>

<?php }} ?>